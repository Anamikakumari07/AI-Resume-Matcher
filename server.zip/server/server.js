require("dotenv").config();
console.log(process.env.MONGODB_URI);
const express = require("express");
const cors = require("cors");

const connectDB = require("./config/db");

const apiRoutes = require("./routes/apiRoutes");

const app = express();

// Connect Database
connectDB();

// Middleware
app.use(cors());
app.use(express.json());

// Routes
app.use("/api", apiRoutes);

// Start Server
app.listen(process.env.PORT, () => {
    console.log(`Server Started on Port ${process.env.PORT}`);
});